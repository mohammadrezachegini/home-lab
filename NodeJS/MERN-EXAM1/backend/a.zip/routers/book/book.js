const  book= require('../../controllers/book.controllers');
const router = require("express").Router();

router.post("/create", book.register )
router.get("/", book.getAllBook )


module.exports = {
    BookRoutes: router
}